### Cocoma
##COordination et COncensus Multi-Agents (Coordination and Multi Agents consensus)
